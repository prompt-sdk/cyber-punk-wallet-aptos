import './dist/svg-icons.scss';

import './dist/svg-icons.woff2';
